<?php
include ("../config.php");

class pesanMasuk extends Config{
	
}


?>